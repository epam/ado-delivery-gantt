export declare const CopiedToClipboard = "Copied to clipboard!";
export declare const CopyToClipboard = "Copy to clipboard";
