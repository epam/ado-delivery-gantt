export declare const CollapseButtonAriaLabel = "Collapse";
export declare const ExpandButtonAriaLabel = "Expand";
