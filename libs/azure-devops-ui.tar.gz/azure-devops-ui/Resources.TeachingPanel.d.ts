export declare const Back = "Back";
export declare const Close = "Close";
export declare const Done = "Done";
export declare const Next = "Next";
