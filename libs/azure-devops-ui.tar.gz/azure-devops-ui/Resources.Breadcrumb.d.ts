export declare const BreadcrumbItemAriaLabel = "Breadcrumb Item";
