export var ExpandTooltip = "Show more information";
export var SplitterCollapsed = "Splitter collapsed";
export var SplitterExpanded = "Splitter expanded";
export var SplitterValueText = "Pane width {0} pixels";
