export declare const ExpandTooltip = "Show more information";
export declare const SplitterCollapsed = "Splitter collapsed";
export declare const SplitterExpanded = "Splitter expanded";
export declare const SplitterValueText = "Pane width {0} pixels";
