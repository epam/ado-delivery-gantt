export declare const Close = "Close";
export declare const Resize = "Resize";
export declare const SizeFormat = "Height {0}, Width {1}";
