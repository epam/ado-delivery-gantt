export var Back = "Back";
export var EnterFullScreen = "Enter full-screen mode";
export var ExitFullScreen = "Exit full-screen mode";
export var Filter = "Filter";
