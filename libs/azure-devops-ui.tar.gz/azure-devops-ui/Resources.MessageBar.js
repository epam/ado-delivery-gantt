export var DismissButtonLabel = "Dismiss {0} message";
export var Error = "error";
export var Info = "info";
export var Success = "success";
export var Warning = "warning";
