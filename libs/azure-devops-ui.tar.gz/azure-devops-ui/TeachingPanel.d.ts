export * from "./Components/TeachingPanel/TeachingPanel";
export * from "./Components/TeachingPanel/TeachingPanel.Props";
