export var AddLabelButtonText = "Add label";
export var AddLabelWatermark = "Type to add a label";
export var LabelInGroup = "This label is already included";
export var LoadingSuggestions = "Loading...";
export var NewLabelSuggestionText = "New label";
