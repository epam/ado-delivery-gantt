export declare const AnnonuceVisibleFilters = "Showing filters {0} through {1}";
export declare const ApplyChangesFilterBarText = "Apply";
export declare const ClearAndDismissFilterBarLinkLabel = "Clear and dismiss filters";
export declare const ClearFilterBarLinkLabel = "Clear filters";
export declare const FilterPageLeftAriaLabel = "See previous group of filters";
export declare const FilterPageRightAriaLabel = "See next group of filters";
