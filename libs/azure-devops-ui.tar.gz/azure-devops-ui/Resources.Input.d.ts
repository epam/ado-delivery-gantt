export declare const ClearFilter = "Clear filter";
export declare const KeywordFilterBarItemPlaceholderText = "Filter by keywords";
