import "es6-promise/auto";
import "es6-object-assign/auto";
import "es6-string-polyfills";
import "intersection-observer";
import "./Core/find";
