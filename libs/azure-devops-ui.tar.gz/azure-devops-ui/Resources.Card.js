export var CollapseButtonAriaLabel = "Collapse";
export var ExpandButtonAriaLabel = "Expand";
