export * from "./Components/Tabs/Tabs.Props";
