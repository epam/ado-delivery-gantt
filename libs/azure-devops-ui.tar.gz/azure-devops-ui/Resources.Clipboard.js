export var CopiedToClipboard = "Copied to clipboard!";
export var CopyToClipboard = "Copy to clipboard";
