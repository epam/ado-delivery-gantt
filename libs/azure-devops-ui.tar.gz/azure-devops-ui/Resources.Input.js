export var ClearFilter = "Clear filter";
export var KeywordFilterBarItemPlaceholderText = "Filter by keywords";
