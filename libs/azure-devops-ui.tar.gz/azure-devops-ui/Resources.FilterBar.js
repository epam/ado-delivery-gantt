export var AnnonuceVisibleFilters = "Showing filters {0} through {1}";
export var ApplyChangesFilterBarText = "Apply";
export var ClearAndDismissFilterBarLinkLabel = "Clear and dismiss filters";
export var ClearFilterBarLinkLabel = "Clear filters";
export var FilterPageLeftAriaLabel = "See previous group of filters";
export var FilterPageRightAriaLabel = "See next group of filters";
