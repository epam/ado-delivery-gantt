export var Close = "Close";
export var Resize = "Resize";
export var SizeFormat = "Height {0}, Width {1}";
