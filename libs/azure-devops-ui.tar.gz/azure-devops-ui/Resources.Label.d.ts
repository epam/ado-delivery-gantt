export declare const AddLabelButtonText = "Add label";
export declare const AddLabelWatermark = "Type to add a label";
export declare const LabelInGroup = "This label is already included";
export declare const LoadingSuggestions = "Loading...";
export declare const NewLabelSuggestionText = "New label";
