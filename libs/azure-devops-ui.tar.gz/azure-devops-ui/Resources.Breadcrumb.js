export var BreadcrumbItemAriaLabel = "Breadcrumb Item";
