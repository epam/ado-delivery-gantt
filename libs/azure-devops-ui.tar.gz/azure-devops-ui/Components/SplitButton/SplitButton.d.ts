/// <reference types="react" />
import "../../CommonImports";
import "../../Core/core.css";
import "./SplitButton.css";
import { ISplitButtonProps } from "./SplitButton.Props";
export declare function SplitButton(props: ISplitButtonProps): JSX.Element;
