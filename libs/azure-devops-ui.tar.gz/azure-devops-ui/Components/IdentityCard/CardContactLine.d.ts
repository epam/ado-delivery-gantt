import "../../CommonImports";
import "../../Core/core.css";
import "./IdentityCard.css";
import * as React from "react";
import { IContactLineProps } from "./ContactCard.Props";
export declare const CardContactLine: React.FunctionComponent<IContactLineProps>;
