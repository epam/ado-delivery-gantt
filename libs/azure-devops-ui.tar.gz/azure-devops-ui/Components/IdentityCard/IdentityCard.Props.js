export var CardType;
(function (CardType) {
    CardType[CardType["Default"] = 0] = "Default";
    CardType[CardType["Contact"] = 1] = "Contact";
    CardType[CardType["Organization"] = 2] = "Organization";
})(CardType || (CardType = {}));
