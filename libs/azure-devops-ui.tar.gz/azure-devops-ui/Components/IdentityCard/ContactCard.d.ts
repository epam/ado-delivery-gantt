import "../../CommonImports";
import "../../Core/core.css";
import "./IdentityCard.css";
import * as React from "react";
import { IContactCardContactLineProps, IContactCardProps } from "./ContactCard.Props";
export declare const ContactCardContactLine: React.FunctionComponent<IContactCardContactLineProps>;
export declare const ContactCard: React.FunctionComponent<IContactCardProps>;
