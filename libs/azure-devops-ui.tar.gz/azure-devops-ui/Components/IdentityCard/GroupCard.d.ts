import "../../CommonImports";
import "../../Core/core.css";
import "./IdentityCard.css";
import * as React from "react";
import { IGroupCardProps } from "./ContactCard.Props";
export declare const GroupCard: React.FunctionComponent<IGroupCardProps>;
