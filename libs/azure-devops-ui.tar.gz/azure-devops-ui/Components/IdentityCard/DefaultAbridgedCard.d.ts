import "../../CommonImports";
import "../../Core/core.css";
import "./IdentityCard.css";
import * as React from "react";
import { IContactCardProps } from "./ContactCard.Props";
export declare const DefaultAbridgedCard: React.FunctionComponent<IContactCardProps>;
