import "../../CommonImports";
import "../../Core/core.css";
import "./IdentityCard.css";
import * as React from "react";
import { IGroupMembersCardProps } from "./ContactCard.Props";
export declare const GroupMembersCard: React.FunctionComponent<IGroupMembersCardProps>;
