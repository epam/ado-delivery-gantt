export var IdentityType;
(function (IdentityType) {
    IdentityType["User"] = "user";
    IdentityType["Group"] = "group";
    IdentityType["Custom"] = "custom";
})(IdentityType || (IdentityType = {}));
