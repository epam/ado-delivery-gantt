import "../../CommonImports";
import "../../Core/core.css";
import "./IdentityPickerDropdown.css";
import * as React from "react";
import { IIdentityPickerDropdownProps } from "./IdentityPickerDropdown.Props";
export declare const IdentityPickerDropdown: React.FunctionComponent<IIdentityPickerDropdownProps>;
