import "../../CommonImports";
import "../../Core/core.css";
import "./Header.css";
import * as React from "react";
import { IHeaderTitleAreaProps } from "./Header.Props";
export declare class HeaderTitleArea extends React.Component<IHeaderTitleAreaProps> {
    render(): JSX.Element;
}
