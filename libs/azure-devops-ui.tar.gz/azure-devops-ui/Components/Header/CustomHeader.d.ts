import "../../CommonImports";
import "../../Core/core.css";
import "./Header.css";
import * as React from "react";
import { ICustomHeaderProps } from "./Header.Props";
export declare class CustomHeader extends React.Component<ICustomHeaderProps> {
    render(): JSX.Element;
}
