import "../../CommonImports";
import "../../Core/core.css";
import "./Header.css";
import * as React from "react";
import { IHeaderDescriptionProps } from "./Header.Props";
export declare class HeaderDescription extends React.Component<IHeaderDescriptionProps> {
    render(): JSX.Element;
}
