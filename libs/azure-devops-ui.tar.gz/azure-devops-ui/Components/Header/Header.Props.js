export var TitleSize;
(function (TitleSize) {
    TitleSize[TitleSize["Medium"] = 0] = "Medium";
    TitleSize[TitleSize["Large"] = 1] = "Large";
    TitleSize[TitleSize["Small"] = 2] = "Small";
})(TitleSize || (TitleSize = {}));
