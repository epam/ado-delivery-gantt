import "../../CommonImports";
import "../../Core/core.css";
import "./Header.css";
import * as React from "react";
import { IHeaderTitleRowProps } from "./Header.Props";
export declare class HeaderTitleRow extends React.Component<IHeaderTitleRowProps> {
    render(): JSX.Element;
}
