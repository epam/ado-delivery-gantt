import "../../CommonImports";
import "../../Core/core.css";
import "./Header.css";
import * as React from "react";
import { IHeaderIconProps } from "./Header.Props";
export declare class HeaderIcon extends React.Component<IHeaderIconProps> {
    render(): JSX.Element;
}
