/// <reference types="react" />
import "../../CommonImports";
import "../../Core/core.css";
import "./Header.css";
import { IHeaderBackButtonProps } from "./Header.Props";
export declare function HeaderBackButton(props: IHeaderBackButtonProps): JSX.Element;
