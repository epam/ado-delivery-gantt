/// <reference types="react" />
import "../../CommonImports";
import "../../Core/core.css";
import "./Breakpoint.css";
import { IBreakpointProps } from "./Breakpoint.Props";
export declare function Breakpoint(props: IBreakpointProps): JSX.Element;
