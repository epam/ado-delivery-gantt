import "../../CommonImports";
import "../../Core/core.css";
import "./Spinner.css";
import * as React from "react";
import { ISpinnerProps } from "./Spinner.Props";
export declare const Spinner: React.FunctionComponent<ISpinnerProps>;
