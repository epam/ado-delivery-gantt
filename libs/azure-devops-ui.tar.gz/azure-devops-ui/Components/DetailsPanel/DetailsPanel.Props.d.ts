export interface IDetailsPanelProps {
    /**
     * Optional className to emit onto the root DetailPanel element
     */
    className?: string;
}
