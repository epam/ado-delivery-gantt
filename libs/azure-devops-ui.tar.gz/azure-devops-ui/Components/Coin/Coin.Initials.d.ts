import { IColor } from '../../Utilities/Color';
export declare function getInitialsColorFromName(displayName: string | undefined): IColor;
export declare function getInitialsFromName(displayName: string | undefined): string;
