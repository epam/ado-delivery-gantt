/// <reference types="react" />
import "../../CommonImports";
import "../../Core/core.css";
import "./Table.css";
import { ITableBreakpointProps } from "./TableBreakpoint.Props";
export declare function TableBreakpoint(props: ITableBreakpointProps): JSX.Element;
