import "../../CommonImports";
import "../../Core/core.css";
import "./ColorSwatchPicker.css";
import * as React from "react";
import { IColorSwatchPickerProps } from "./ColorSwatchPicker.Props";
export declare const ColorSwatchPicker: React.SFC<IColorSwatchPickerProps>;
