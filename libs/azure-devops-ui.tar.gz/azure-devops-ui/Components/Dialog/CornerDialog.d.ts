import "../../CommonImports";
import "../../Core/core.css";
import "./Dialog.css";
import * as React from "react";
import { ICornerDialogProps } from './Dialog.Props';
export declare class CornerDialog extends React.Component<ICornerDialogProps> {
    render(): JSX.Element;
}
