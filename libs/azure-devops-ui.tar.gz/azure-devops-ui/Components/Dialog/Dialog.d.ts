import "../../CommonImports";
import "../../Core/core.css";
import "./Dialog.css";
import * as React from "react";
import { IDialogProps } from './Dialog.Props';
export declare class Dialog extends React.Component<IDialogProps> {
    render(): JSX.Element;
}
