import "../../CommonImports";
import "../../Core/core.css";
import "./Card.css";
import * as React from "react";
import { ICardProps } from "./Card.Props";
export declare const CustomCard: React.SFC<ICardProps>;
