import "../../CommonImports";
import "../../Core/core.css";
import "./Card.css";
import * as React from "react";
import { ICardContentProps } from "./Card.Props";
export declare const CardContent: React.SFC<ICardContentProps>;
