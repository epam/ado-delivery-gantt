import "../../CommonImports";
import "../../Core/core.css";
import "./Card.css";
import * as React from "react";
import { ICardFooterProps } from "./Card.Props";
export declare const CardFooter: React.SFC<ICardFooterProps>;
