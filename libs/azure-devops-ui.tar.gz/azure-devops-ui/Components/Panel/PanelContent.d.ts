import "../../CommonImports";
import "../../Core/core.css";
import "./Panel.css";
import * as React from "react";
import { IPanelContentProps } from './Panel.Props';
export declare const PanelContent: React.SFC<IPanelContentProps>;
