import "../../CommonImports";
import "../../Core/core.css";
import "./Panel.css";
import * as React from "react";
import { IPanelOverlayProps } from './Panel.Props';
export declare const PanelOverlay: React.SFC<IPanelOverlayProps>;
