import "../../CommonImports";
import "../../Core/core.css";
import "./Panel.css";
import * as React from "react";
import { IPanelFooterProps } from './Panel.Props';
export declare const PanelFooter: React.SFC<IPanelFooterProps>;
