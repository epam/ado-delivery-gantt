import "../../CommonImports";
import "../../Core/core.css";
import "./Panel.css";
import * as React from "react";
import { IPanelHeaderProps } from './Panel.Props';
export declare const PanelHeader: React.SFC<IPanelHeaderProps>;
