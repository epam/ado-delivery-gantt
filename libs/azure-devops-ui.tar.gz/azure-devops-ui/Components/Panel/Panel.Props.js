export var PanelCloseButtonSize;
(function (PanelCloseButtonSize) {
    PanelCloseButtonSize[PanelCloseButtonSize["small"] = 0] = "small";
    PanelCloseButtonSize[PanelCloseButtonSize["large"] = 1] = "large";
})(PanelCloseButtonSize || (PanelCloseButtonSize = {}));
