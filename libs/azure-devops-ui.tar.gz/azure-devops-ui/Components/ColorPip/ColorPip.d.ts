import "../../CommonImports";
import "../../Core/core.css";
import "./ColorPip.css";
import * as React from "react";
import { IColorPipProps } from "./ColorPip.Props";
export declare class ColorPip extends React.Component<IColorPipProps> {
    private rootRef;
    render(): JSX.Element;
    private onClick;
}
