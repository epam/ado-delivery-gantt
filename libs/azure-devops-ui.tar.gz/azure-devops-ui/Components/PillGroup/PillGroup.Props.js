export var PillGroupOverflow;
(function (PillGroupOverflow) {
    PillGroupOverflow[PillGroupOverflow["clip"] = 0] = "clip";
    PillGroupOverflow[PillGroupOverflow["wrap"] = 1] = "wrap";
    PillGroupOverflow[PillGroupOverflow["fade"] = 2] = "fade";
})(PillGroupOverflow || (PillGroupOverflow = {}));
