export var WrappingBehavior;
(function (WrappingBehavior) {
    WrappingBehavior[WrappingBehavior["freeFlow"] = 0] = "freeFlow";
    WrappingBehavior[WrappingBehavior["oneLine"] = 1] = "oneLine";
})(WrappingBehavior || (WrappingBehavior = {}));
