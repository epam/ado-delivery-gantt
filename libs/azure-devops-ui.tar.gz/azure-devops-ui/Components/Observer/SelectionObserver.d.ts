import "../../CommonImports";
import "../../Core/core.css";
import * as React from "react";
import { ISelectionObserverProps } from "./SelectionObserver.Props";
export declare class SelectionObserver extends React.Component<ISelectionObserverProps> {
    render(): JSX.Element;
    private onSelectionChanged;
}
