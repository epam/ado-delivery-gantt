/// <reference types="react" />
import "../../CommonImports";
import "../../Core/core.css";
import "./List.css";
import "./ListDropIndicator.css";
import { IListDropIndicatorProps } from "./ListDropIndicator.Props";
export declare function ListDropIndicator(props: IListDropIndicatorProps): JSX.Element;
