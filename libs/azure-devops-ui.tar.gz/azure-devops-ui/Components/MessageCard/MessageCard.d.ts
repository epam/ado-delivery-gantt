import "../../CommonImports";
import "../../Core/core.css";
import "./MessageCard.css";
import * as React from "react";
import { IMessageCardProps } from "./MessageCard.Props";
export declare const MessageCard: React.FunctionComponent<IMessageCardProps>;
