import "../../CommonImports";
import "../../Core/core.css";
import "./ZeroData.css";
export * from "./ZeroData";
export * from "./ZeroData.Props";
