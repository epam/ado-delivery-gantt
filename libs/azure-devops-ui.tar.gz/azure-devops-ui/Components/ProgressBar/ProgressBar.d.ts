import "../../CommonImports";
import "../../Core/core.css";
import "./ProgressBar.css";
import * as React from "react";
import { IProgressBarProps } from "./ProgressBar.Props";
export declare const ProgressBar: React.FunctionComponent<IProgressBarProps>;
