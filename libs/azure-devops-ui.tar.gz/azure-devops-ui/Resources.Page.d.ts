export declare const Back = "Back";
export declare const EnterFullScreen = "Enter full-screen mode";
export declare const ExitFullScreen = "Exit full-screen mode";
export declare const Filter = "Filter";
