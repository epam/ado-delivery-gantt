export * from "./Components/Persona/Persona";
export * from "./Components/Persona/Persona.Props";
