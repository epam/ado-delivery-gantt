export declare const DismissButtonLabel = "Dismiss {0} message";
export declare const Error = "error";
export declare const Info = "info";
export declare const Success = "success";
export declare const Warning = "warning";
